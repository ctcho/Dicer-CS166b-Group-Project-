$("#search").click(function() {
  $("#search_modal").css("display", "block");
});

$(".close").click(function() {
  $("#search_modal").css("display", "none");
})
;

$("#contact").click(function() {
    $(".modall").css("display", "block");
    console.log("lorem ipsum dolor sit amet");
});

$(".close").click(function() {
  $("#msgmodal").css("display", "none");
});

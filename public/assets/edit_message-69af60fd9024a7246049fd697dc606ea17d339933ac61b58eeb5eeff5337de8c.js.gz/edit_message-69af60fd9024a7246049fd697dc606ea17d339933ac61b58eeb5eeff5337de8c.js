$('#edit-msg').click(function() {
  console.log("Let's pray that this is working");
  event.preventDefault();
});
